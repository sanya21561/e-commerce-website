import React from 'react'
import axios from 'axios'
import { useState } from 'react';

const Checkout = () => {


  return (
    <div className="max-w-md mx-auto bg-white shadow-md rounded p-4">
      
    </div>
  );
}

export default Checkout
