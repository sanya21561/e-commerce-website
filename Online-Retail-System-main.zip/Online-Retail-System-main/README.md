# Online-Retail-System
A project for Database and Management System course @ IIITD

